#include <iostream>
#include <string>
#include  "point.h"

using namespace std;

class cercle {
    private:
    point centre;
    double R;
    public:
    cercle();
    cercle(double z,double x,double y);
    void affichage();
    void setRayon(double z);
    .
    double surface();
    double perimetre();
    .
    bool appartenance(point p);
};
