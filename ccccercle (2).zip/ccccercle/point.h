#include <iostream>
#include <string>

using namespace std;
class point {
private:
double x;
double y;
public:
point();
point(double x,double y);
void affichage();
double distance(point p);
};
