#include <iostream>
#include <math.h>
#include  "point.h"
#include  "cercle.h"


double cercle ::  cercle(double z, point p){
        R = z;
        centre = p; }

double cercle :: cercle(double z,double x,double y){
 

   }

 void  affichage(){
cout << 
cout << << endl;
cout << << endl;
 }
  void setRayon(double z){
         R = z; }

double cercle :: surface(){
         return R * R * 3.14;
    }

  double cercle :: perimetre(){
         return 2 * 3.14 * R;
  } 

 bool cercle :: appartenance(point p){

     if(centre.distance(p) <= R)
     return true;
     else
     return false;
 }