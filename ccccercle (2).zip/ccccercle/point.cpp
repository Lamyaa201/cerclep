#include <iostream>
#include <string>
#include  "point.h"

using namespace std;

double point :: point(){
    this->x=0;
    this->y=0;
}
double point :: point(double x,double y){
    this->x=x;
    this->y=y; }

 void  affichage(){
        cout << "point(" << x << "," << y << ")";
    }
 double point :: distance(point p){
    return sqrt(pow(x - p.x , 2) + pow(y - p.y , 2));
    }
